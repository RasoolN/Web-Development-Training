function foo (p1) {
	if (typeof(p1) == "number")
		return 0;	// Return a number
	else
	if (typeof(p1) == "string")
		return "zero"; // Return a string

	// If no value being explicitly returned 
	// "undefined" is returned.
}



function popup() {
alert("Hello World")
}